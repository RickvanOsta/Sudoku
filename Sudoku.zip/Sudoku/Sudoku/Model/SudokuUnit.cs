﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sudoku.Model
{
    public class SudokuUnit
    {

        public string value { get; set; }
        public string xCord { get; set; }
        public string yCord { get; set; }




    }
}
