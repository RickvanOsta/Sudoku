﻿using Microsoft.Owin;
using Owin;


namespace SudokuMVC
{
    public class Startup
    {
        public void Configuration()
        {
            
        }
    }
}
